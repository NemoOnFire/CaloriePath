# CaloriePath TDEE Calculator

This is a no-framework starter website. Open `index.html` in a browser to test it.

Included:
- Mifflin-St Jeor BMR estimate
- TDEE estimate using activity multipliers
- Maintenance / loss / gain calorie estimates
- Simple protein target
- Mobile-friendly design
- SEO title and description
- Educational content section

Next steps before public launch:
1. Pick a domain name.
2. Put the site on a free static host such as GitHub Pages, Cloudflare Pages, or Netlify.
3. Add separate pages for BMR, BMI, macros, protein, and weight-loss timeline.
4. Add analytics and search-console setup.
5. Add monetization only after the site has useful traffic.
6. Review health/fitness claims and add appropriate disclaimers before launch.
